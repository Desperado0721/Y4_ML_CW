'''
2021/12/24
Qingyang LU

Enviroments:
python 3.7.3
sklearn 0.23.2
numpy 1.16.2

'''
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


def unpickle(file):
    import pickle
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='latin1')
    return dict


# unpickle data
data_1 = unpickle('data_batch_1')
data_2 = unpickle('data_batch_2')
data_3 = unpickle('data_batch_3')
data_4 = unpickle('data_batch_4')
data_5 = unpickle('data_batch_5')
test_data = unpickle('test_batch')['data']
test_label = unpickle('test_batch')['labels']

# stack data from 5 batches to get the complete train set
train_label_list = []
train_data_list = []
for data in [data_1, data_2, data_3, data_4, data_5]:
    current_label = data['labels']
    current_data = data['data']
    train_label_list.append(current_label)
    train_data_list.append(current_data)

train_label = np.hstack(train_label_list)
train_data = np.vstack(np.array(train_data_list))

# Due to the limitation of computing power, smaller train set and test set was used.
train_data_small = np.reshape(train_data[0:5000], (5000, 3072))
train_label_small = train_label[0:5000]
test_data_small = np.reshape(test_data[0:1000], (1000, 3072))
test_label_small = test_label[0:1000]

# standardization
ss = StandardScaler()
train_data_small = ss.fit_transform(train_data_small)
test_data_small = ss.fit_transform(test_data_small)
train_data = ss.fit_transform(train_data)
test_data = ss.fit_transform(test_data)
np.save('train_data_small.npy', train_data_small)
np.save('test_data_small.npy', test_data_small)
np.save('train_label_small.npy', train_label_small)
np.save('test_label_small.npy', test_label_small)
np.save('train_data_big.npy', train_data)
np.save('train_label_big.npy', train_label)
np.save('test_data_big.npy', test_data)
np.save('test_label_big.npy', test_label)

# apply PCA to reduce feature information with different amount of information kept
# Find coponents that keep 30%, 50%, 70%, 100% information(no coponent keep 10% information)
k = 0
p = 0
pca_conponent_list = []
target_ratio = [0.3, 0.5, 0.7, 0.9]
error = 0
min_error = 1
for i in range(100):
    pca = PCA(n_components=i)  # you can try different value here
    train_data_trans = pca.fit_transform(train_data_small)
    error = abs(sum(pca.explained_variance_ratio_) - target_ratio[k])
    if error <= min(0.1, min_error):
        min_error = error
        closest_information_ratio = sum(pca.explained_variance_ratio_)
        p = 1
    else:
        if p == 1:
            p = 0
            pca_conponent_list.append(i - 1)
            print('when coponent=', i - 1, ',pca keep', target_ratio[k] * 100, '% information', )
            print(closest_information_ratio)
            print('Noise variance: ', pca.noise_variance_)

            if k != 3:
                k = k + 1
            else:
                break
print('conponent_list:',pca_conponent_list)
# result: pca_conponent_list=[1, 4, 15, 98]


# save the transfromed data after PCA
target_ratio = [30, 50, 70, 90]
for i in range(4):
    pca = PCA(n_components=pca_conponent_list[i])  # you can try different value here
    train_data_trans = pca.fit_transform(train_data_small)
    test_data_trans = pca.fit_transform(test_data_small)
    np.save('train_data_trans_{}'.format(target_ratio[i]), train_data_trans)
    np.save('test_data_trans_{}'.format(target_ratio[i]), test_data_trans)
