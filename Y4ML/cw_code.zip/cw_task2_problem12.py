'''
2021/12/24
Qingyang LU

Enviroments:
python 3.7.3
sklearn 0.23.2
numpy 1.16.2

'''
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import cross_val_score
from sklearn.neural_network import MLPClassifier
import joblib

# load original data and transformed data after PCA
train_datas = ['train_data_trans_30', 'train_data_trans_50',
               'train_data_trans_70', 'train_data_trans_90', 'train_data_small']
test_datas = ['test_data_trans_30', 'test_data_trans_50', 'test_data_trans_70', 'test_data_trans_90', 'test_data_small']
labels = ['train_label_small', 'test_label_small']
for i in range(len(train_datas)):
    locals()[train_datas[i]] = np.load('{}.npy'.format(train_datas[i]))
for i in range(len(test_datas)):
    locals()[test_datas[i]] = np.load('{}.npy'.format(test_datas[i]))
for i in range(len(labels)):
    locals()[labels[i]] = np.load('{}.npy'.format(labels[i]))

scores = np.zeros(len(train_datas))
accuracys = np.zeros(len(train_datas))
f1scores_macro = np.zeros(len(train_datas))
f1scores_micro = np.zeros(len(train_datas))
precisions = np.zeros(len(train_datas))
recalls = np.zeros(len(train_datas))

# Use 10 fold cross validation to train mlp model with different input feature vcctor
for i in range(len(train_datas)):
    mlp = MLPClassifier(hidden_layer_sizes=(1024, 1024, 1024), activation='relu', max_iter=1000, solver='adam',
                        verbose=10, learning_rate_init=0.001)
    score = cross_val_score(mlp, locals()[train_datas[i]], train_label_small, cv=10).mean()
    scores[i] = score
    mlp = mlp.fit(locals()[train_datas[i]], train_label_small)
    # save models
    joblib.dump(mlp, 'mlp_{}.pkl'.format(train_datas[i]))
    test_pred = mlp.predict(locals()[test_datas[i]])
    accuracy = accuracy_score(test_label_small, test_pred)
    print(accuracy)
    accuracys[i] = accuracy
    f1_score_macro = f1_score(test_label_small, test_pred, average='macro')
    f1scores_macro[i] = f1_score_macro
    f1_score_micro = f1_score(test_label_small, test_pred, average='micro')
    f1scores_micro[i] = f1_score_micro
    precision_score_micro = precision_score(test_label_small, test_pred, average='micro')
    precisions[i] = precision_score_micro
    recall_score_micro = recall_score(test_label_small, test_pred, average='micro')
    recalls[i] = recall_score_micro

metrics = np.vstack((scores, accuracys, f1scores_macro, f1scores_micro, precisions, recalls))

# record results into a dataframe
df = pd.DataFrame(metrics,
                  columns=['30%PCA data(1)', '50%PCA data(4)', '70%PCA data(15)', '90%PCA data(98)', 'Full data(3072)'],
                  index=['validation score', 'accuracy', 'F1_score_macro', 'F1_score_micro', 'precision', 'recall'])
df = pd.DataFrame(metrics, columns=['1', '4', '15', '98', '3072'],
                  index=['validation score', 'accuracy', 'F1_score_macro', 'F1_score_micro', 'precision', 'recall'])
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
print(df)
# save the dataframe as a csv file
df.to_csv('metrics.csv')

# read dataframe from csv file
df = pd.read_csv('metrics.csv', index_col=0)
df.columns = ['1', '4', '15', '98', '3072']
print(df)

# plot figures showing validation score vs feature dimension
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set(ylabel='validation score')
ax.set(xlabel='Number of features')
ax.set_title("10 fold validation score")
ax.plot(df.iloc[0])
fig.savefig("validation score.png")
plt.show()

# plot figures showing result and macro f1 score vs feature dimension
fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.set(ylabel='accuracy')
ax1.plot(df.iloc[1], label='accuracy', color='r')
ax1.set_title("accuracy and f1 score")
ax1.legend(loc='upper left')
ax2 = ax1.twinx()
ax2.set(ylabel='f1 score')
ax2.set(xlabel='Number of features')
ax2.plot(df.iloc[2], label='f1_score')
ax2.legend(loc='upper right')
fig.savefig("accuracy and f1 score.png")
plt.show()
