'''
2021/12/24
Qingyang LU

Enviroments:
python 3.7.3
sklearn 0.23.2
numpy 1.16.2

'''

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report
from sklearn.model_selection import cross_val_score
from sklearn.neural_network import MLPClassifier

# load the original data
train_datas = ['train_data_small']
test_datas = ['test_data_small']
labels = ['train_label_small', 'test_label_small']
for i in range(len(train_datas)):
    locals()[train_datas[i]] = np.load('{}.npy'.format(train_datas[i]))
for i in range(len(test_datas)):
    locals()[test_datas[i]] = np.load('{}.npy'.format(test_datas[i]))
for i in range(len(labels)):
    locals()[labels[i]] = np.load('{}.npy'.format(labels[i]))

# train MLP with different hyper parameters and do 10 fold cv
scores = np.zeros(16)
accuracys = np.zeros(16)
f1scores_macro = np.zeros(16)
f1scores_micro = np.zeros(16)
i = 0
for size in [128, 256, 1024, 2048]:
    for learning_rate_init in [0.01, 0.001, 0.0001]:
        mlp = MLPClassifier(hidden_layer_sizes=(size, size, size), activation='relu', max_iter=1000, solver='adam',
                            verbose=False,
                            learning_rate_init=learning_rate_init, learning_rate='adaptive')
        score = cross_val_score(mlp, train_data_small, train_label_small, cv=10).mean()
        mlp = mlp.fit(train_data_small, train_label_small)
        test_pred = mlp.predict(test_data_small)
        report = classification_report(test_label_small, test_pred)
        # print the f1_score for each class and the accuracy
        print('size=%f,learning_rate_init=%f,results on test set:\n%s' % (size, learning_rate_init, report))
        accuracy = accuracy_score(test_label_small, test_pred)
        accuracys[i] = accuracy
        f1_score_macro = f1_score(test_label_small, test_pred, average='macro')
        f1scores_macro[i] = f1_score_macro
        f1_score_micro = f1_score(test_label_small, test_pred, average='micro')
        f1scores_micro[i] = f1_score_micro
        i = i + 1

# write results into a numpy file
metrics1 = np.vstack((scores, accuracys, f1scores_macro, f1scores_micro))
np.save('metrics1.npy', metrics1)

# Build three dataframe to record the performance of model with different hyperparameters
metrics = np.load('metrics.npy')[:, :12]
df_validation_score = pd.DataFrame(np.reshape(metrics[0], (4, 3)),
                                   columns=['learning rate init 0.01', '0.001', '0.0001'],
                                   index=['hidden layer size 128', '256', '1024', '2048'])
df_accuracy = pd.DataFrame(np.reshape(metrics[1], (4, 3)), columns=['learning rate init 0.01', '0.001', '0.0001'],
                           index=['hidden layer size 128', '256', '1024', '2048'])
df_f1_score = pd.DataFrame(np.reshape(metrics[2], (4, 3)), columns=['learning rate init 0.01', '0.001', '0.0001'],
                           index=['hidden layer size 128', '256', '1024', '2048'])
print(df_validation_score)
print(df_accuracy)
print(df_f1_score)
