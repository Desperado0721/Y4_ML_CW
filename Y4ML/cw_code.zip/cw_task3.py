'''
2021/12/24
Qingyang LU

Enviroments:
python 3.7.3
sklearn 0.23.2
pytorch 1.10.0
'''

import torch
import torchvision
import torchvision.transforms as transforms
import torch.nn as nn
import torch.nn.functional as F
import time
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

# Use GPU to train
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(device)

if __name__ == '__main__':

    # define the transform rule and batch_size
    transform = transforms.Compose(
        [transforms.ToTensor(),
         transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

    # batch_size=8 acheived best performance in this network
    batch_size = 8
    # download and load Cifar10 dataset
    trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    trainloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size,
                                              shuffle=True, num_workers=2)
    # trainloader1 is used to test the performance on trainset
    trainloader1 = torch.utils.data.DataLoader(trainset, batch_size=50000,
                                               shuffle=True, num_workers=2)
    testset = torchvision.datasets.CIFAR10(root='./data', train=False,
                                           download=True, transform=transform)
    testloader = torch.utils.data.DataLoader(testset, batch_size=10000,
                                             shuffle=False, num_workers=2)

    start = time.time()


    # define the network
    class Net(nn.Module):
        def __init__(self):
            super().__init__()
            # build a convolution layer with, input channel=3(input data has 3 channels),
            # output channel=6, the size of filter is 3*3, stride=1
            self.conv1 = nn.Conv2d(3, 6, 3)

            # definepooling layer with with 2*2 filter with stride=2
            self.pool = nn.MaxPool2d(2, 2)

            # build a convolution layer with, input channel=6, output channel=12, 3*3
            self.conv2 = nn.Conv2d(6, 12, 3)

            # build a convolution layer with, input channel=12, output channel=24, 3*3
            self.conv3 = nn.Conv2d(12, 24, 3)

            # build three linearization layers
            self.fc1 = nn.Linear(96, 48)
            self.fc2 = nn.Linear(48, 24)
            self.fc3 = nn.Linear(24, 10)

        def forward(self, x):
            x = self.pool(F.relu(self.conv1(x)))
            x = self.pool(F.relu(self.conv2(x)))
            x = self.pool(F.relu(self.conv3(x)))
            x = torch.flatten(x, 1)  # flatten all dimensions except batch
            x = F.relu(self.fc1(x))
            x = F.relu(self.fc2(x))
            x = self.fc3(x)
            return x


    net = Net().to(device)

    # choose CrossEntropyLoss as loss function, SGD as optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(net.parameters(), lr=0.001, momentum=0.9)

    for epoch in range(200):  # loop over the dataset 200 times
        running_loss = 0.0
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)

            # zero the parameter gradients
            optimizer.zero_grad()

            # forward + backward + optimize
            outputs = net(inputs)

            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # print running loss
            running_loss += loss.item()
            if i % 2500 == 2499:  # print every 2000 mini-batches
                print('[%d, %5d] loss: %.3f' %
                      (epoch + 1, i + 1, running_loss / 2500))
                running_loss = 0.0

    print('Finished Training')
    end = time.time()
    print('training time:', end - start)

    # save and load weights of model
    PATH = './cifar10_cnn200_1.pth'
    torch.save(net.state_dict(), PATH)

    net = Net()
    net.load_state_dict(torch.load(PATH))

    # test the model on test set
    for i, data in enumerate(testloader, 0):
        test_inputs, test_labels = data
        test_outputs = net(test_inputs)
        _, test_pred = torch.max(test_outputs, 1)
        print('cnn performance on testset')
        print(classification_report(test_labels, test_pred))

    # test the model on train set
    for i, data in enumerate(trainloader1, 0):
        train_inputs, train_labels = data
        train_outputs = net(train_inputs)
        _, train_pred = torch.max(train_outputs, 1)
        accuracy = accuracy_score(train_labels, train_pred)
        print('cnn_train_accuracy:', accuracy)

# plot
# accuracy=[0.61,0.63, 0.64, 0.62, 0.63]
# f1_score=[0.61,0.62, 0.64, 0.62, 0.64]
# epoch=[10, 100, 200, 500, 1000]
# fig = plt.figure()
# ax1 = fig.add_subplot(111)
# ax1.set(ylabel='accuracy')
# ax1.plot(epoch,accuracy, label='accuracy', color='r')
# ax1.set_title("accuracy and f1 score")
# ax1.legend(loc='upper left')
# ax2 = ax1.twinx()
# ax2.set(ylabel='f1 score')
# ax2.set(xlabel='Number of features')
# ax2.plot(epoch,f1_score, label='f1_score')
# ax2.legend(loc='upper right')
# fig.savefig("accuracy and f1 score_cnn.png")
# plt.show()
