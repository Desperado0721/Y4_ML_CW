'''
2021/12/24
Qingyang LU

Enviroments:
python 3.7.3
sklearn 0.23.2
pytorch 1.10.0
'''
import numpy as np
import time
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.neural_network import MLPClassifier
import joblib

train_datas = ['train_data_big']
test_datas = ['test_data_big']
labels = ['train_label_big', 'test_label_big']
for i in range(len(train_datas)):
    locals()[train_datas[i]] = np.load('{}.npy'.format(train_datas[i]))
for i in range(len(test_datas)):
    locals()[test_datas[i]] = np.load('{}.npy'.format(test_datas[i]))
for i in range(len(labels)):
    locals()[labels[i]] = np.load('{}.npy'.format(labels[i]))

# use the complete cifar10 dataset(50000*3072) and optimal hyperparameters in task 3 to get the best performance of mlp on complete dataset
# Result of CNN had been recorded in 'cw_task3.py'
start = time.time()

mlp = MLPClassifier(hidden_layer_sizes=(2048, 2048, 2048), activation='relu', max_iter=1000, solver='adam', verbose=10,
                    learning_rate_init=0.0001, learning_rate='adaptive')
mlp = mlp.fit(train_data_big, train_label_big)
end = time.time()
joblib.dump(mlp, 'best_mlp_big.pkl')

train_predict = mlp.predict(train_data_big)
train_accuracy = accuracy_score(train_label_big, train_predict)
test_pred = mlp.predict(test_data_big)

end = time.time()
print('training time:', end - start)
print('mlp train accuracy:', train_accuracy)
print(classification_report(test_label_big, test_pred))
